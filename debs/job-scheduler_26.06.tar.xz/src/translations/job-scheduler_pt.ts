<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="pt">
<context>
    <name>CronModel</name>
    <message>
        <location filename="../src/CronModel.cpp" line="130"/>
        <source>Time</source>
        <translation>Horário</translation>
    </message>
    <message>
        <location filename="../src/CronModel.cpp" line="132"/>
        <source>User</source>
        <translation>Utilizador</translation>
    </message>
    <message>
        <location filename="../src/CronModel.cpp" line="134"/>
        <source>Command</source>
        <translation>Comando</translation>
    </message>
</context>
<context>
    <name>ExecuteList</name>
    <message>
        <location filename="../src/ExecuteList.cpp" line="43"/>
        <source>Max Item</source>
        <translation>Item máximo</translation>
    </message>
    <message>
        <location filename="../src/ExecuteList.cpp" line="45"/>
        <source>Max Date</source>
        <translation>Data máxima</translation>
    </message>
    <message>
        <location filename="../src/ExecuteList.cpp" line="47"/>
        <source>Select</source>
        <translation>Selecionar</translation>
    </message>
    <message>
        <location filename="../src/ExecuteList.cpp" line="52"/>
        <source>&amp;Update</source>
        <translation>&amp;Atualizar</translation>
    </message>
</context>
<context>
    <name>ExecuteModel</name>
    <message>
        <location filename="../src/ExecuteModel.cpp" line="65"/>
        <source>Execute Time</source>
        <translation>Execução</translation>
    </message>
    <message>
        <location filename="../src/ExecuteModel.cpp" line="67"/>
        <source>Time</source>
        <translation>Horário</translation>
    </message>
    <message>
        <location filename="../src/ExecuteModel.cpp" line="69"/>
        <source>User</source>
        <translation>Utilizador</translation>
    </message>
    <message>
        <location filename="../src/ExecuteModel.cpp" line="71"/>
        <source>Command</source>
        <translation>Comando</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/MainWindow.cpp" line="55"/>
        <source>&amp;Command</source>
        <translation>&amp;Comando</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="57"/>
        <source>&amp;Variables</source>
        <translation>&amp;Variáveis</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="59"/>
        <source>&amp;Job List</source>
        <translation>Lista de &amp;tarefas</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="98"/>
        <location filename="../src/MainWindow.cpp" line="193"/>
        <location filename="../src/MainWindow.cpp" line="236"/>
        <location filename="../src/MainWindow.cpp" line="257"/>
        <location filename="../src/MainWindow.cpp" line="326"/>
        <source>Job Scheduler</source>
        <translation>Agendador de Tarefas</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="125"/>
        <source>&amp;File</source>
        <translation>&amp;Ficheiro</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="126"/>
        <source>File</source>
        <translation>Ficheiro</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="129"/>
        <source>&amp;New Item</source>
        <translation>&amp;Novo item</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="130"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="133"/>
        <source>&amp;Reload</source>
        <translation>&amp;Recarregar</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="134"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="136"/>
        <source>&amp;Save</source>
        <translation>&amp;Guardar</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="137"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="140"/>
        <source>Start as &amp;Root</source>
        <translation>Iniciar como &amp;Root</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="142"/>
        <source>Start as &amp;Regular user</source>
        <translation>Iniciar como &amp;Utilizador normal</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="144"/>
        <source>Ctrl+U</source>
        <translation>Ctrl+U</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="147"/>
        <source>E&amp;xit</source>
        <translation>&amp;Sair</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="148"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="155"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="156"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="158"/>
        <source>Cu&amp;t</source>
        <translation>Cor&amp;tar</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="159"/>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="161"/>
        <source>&amp;Copy</source>
        <translation>&amp;Copiar</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="162"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="164"/>
        <source>&amp;Paste</source>
        <translation>Co&amp;lar</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="165"/>
        <source>Ctrl+V</source>
        <translation>Ctrl+V</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="168"/>
        <source>&amp;Delete</source>
        <translation>&amp;Eliminar</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="169"/>
        <source>Del</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="180"/>
        <location filename="../src/MainWindow.cpp" line="182"/>
        <source>&amp;Help</source>
        <translation>&amp;Ajuda</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="181"/>
        <source>&amp;About</source>
        <translation>&amp;Sobre</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="237"/>
        <source>Not saved since last change.
Are you OK to reload?</source>
        <translation>Não guardado desde a última alteração.
Recarregar?</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="326"/>
        <source>Not saved since last change.
Are you OK to exit?</source>
        <translation>Não guardado desde a última alteração.
Sair?</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="339"/>
        <source>About Job Scheduler</source>
        <translation>Sobre o Agendador de Tarefas</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="340"/>
        <source>&lt;b&gt;Job Scheduler&lt;/b&gt;</source>
        <translation>&lt;b&gt;Agendador de Tarefas&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="340"/>
        <source>Version: %1</source>
        <translation>Versão: %1</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="341"/>
        <source>Job Scheduler is based upon qroneko 0.5.4, released in 2005 by korewaisai (&lt;a href=&quot;mailto:korewaisai@yahoo.co.jp&quot;&gt;korewaisai@yahoo.co.jp&lt;/a&gt;)</source>
        <translation>O Agendador de Tarefas baseia-se no qroneko 0.5.4, lançado em 2005 por korewaisai (&lt;a href=&quot;mailto:korewaisai@yahoo.co.jp&quot;&gt;korewaisai@yahoo.co.jp&lt;/a&gt;)</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="344"/>
        <source>Original project page: %1</source>
        <translation>Página do projecto original: %1</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="348"/>
        <source>MX project page: %1</source>
        <translation>Página do projecto no MX: %1</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="353"/>
        <source>%1 License</source>
        <translation>Licença do %1</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="52"/>
        <source>Could not load %1</source>
        <translation>Foi impossível carregar %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="74"/>
        <source>License</source>
        <translation>Licença</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="75"/>
        <location filename="../src/about.cpp" line="84"/>
        <source>Changelog</source>
        <translation>Registo de alterações</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="76"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>Could not load changelog.</source>
        <translation>Falha ao carregar registo de alterações.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="32"/>
        <location filename="../src/about.cpp" line="99"/>
        <source>&amp;Close</source>
        <translation>&amp;Fechar</translation>
    </message>
</context>
<context>
    <name>SaveDialog</name>
    <message>
        <location filename="../src/SaveDialog.cpp" line="21"/>
        <source>Save New Schedule</source>
        <translation>Guardar novo agendamento</translation>
    </message>
    <message>
        <location filename="../src/SaveDialog.cpp" line="34"/>
        <source>User:</source>
        <translation>Utilizador:</translation>
    </message>
    <message>
        <location filename="../src/SaveDialog.cpp" line="42"/>
        <source>&amp;OK</source>
        <translation>&amp;Aceitar</translation>
    </message>
    <message>
        <location filename="../src/SaveDialog.cpp" line="43"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
</context>
<context>
    <name>TCommandEdit</name>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="43"/>
        <source>User:</source>
        <translation>Utilizador:</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="51"/>
        <source>Time:</source>
        <translation>Horário:</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="55"/>
        <source>Time String E&amp;ditor</source>
        <translation>E&amp;ditor de horário</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="60"/>
        <source>Command:</source>
        <translation>Comando:</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="66"/>
        <source>Comment:</source>
        <translation>Comentário:</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="69"/>
        <source>Job Schedule:</source>
        <translation>Agendamento:</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="131"/>
        <source>Time Format Error</source>
        <translation>Erro no formato do horário</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="145"/>
        <source>No matching schedule</source>
        <translation>Nenhum agendamento coincidente</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="154"/>
        <source>Today</source>
        <translation>Hoje</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="156"/>
        <source>Tomorrow</source>
        <translation>Amanhã</translation>
    </message>
</context>
<context>
    <name>TimeDialog</name>
    <message>
        <location filename="../src/TimeDialog.cpp" line="78"/>
        <source>time</source>
        <translation>horário</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="83"/>
        <source>Minute</source>
        <translation>Minuto</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="95"/>
        <source>Hour</source>
        <translation>Hora</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="101"/>
        <source>AM </source>
        <translation>AM </translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="107"/>
        <source>PM </source>
        <translation>PM </translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="114"/>
        <source>Day</source>
        <translation>Dia</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="129"/>
        <source>Month</source>
        <translation>Mês</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="143"/>
        <source>Week</source>
        <translation>Semana</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="155"/>
        <source>Simple</source>
        <translation>Simples</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="169"/>
        <source>Enable Literal</source>
        <translation>Ativar Literal</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="171"/>
        <source>&amp;Reset</source>
        <translation>&amp;Repor</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="172"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="173"/>
        <source>&amp;Ok</source>
        <translation>&amp;Aceitar</translation>
    </message>
</context>
<context>
    <name>VariableEdit</name>
    <message>
        <location filename="../src/VariableEdit.cpp" line="50"/>
        <source>Variables</source>
        <translation>Variáveis</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="55"/>
        <source>Mail:</source>
        <translation>Correio:</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="56"/>
        <source>Don&apos;t send</source>
        <translation>Não enviar</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="57"/>
        <source>Send</source>
        <translation>Enviar</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="58"/>
        <source>To</source>
        <translation>Para</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="70"/>
        <source>&amp;New</source>
        <translation>&amp;Novo</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="73"/>
        <source>&amp;Delete</source>
        <translation>&amp;Eliminar</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="81"/>
        <source>Name:</source>
        <translation>Nome: </translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="86"/>
        <source>Value:</source>
        <translation>Valor: </translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="89"/>
        <source>Comment:</source>
        <translation>Comentário:</translation>
    </message>
</context>
<context>
    <name>VariableModel</name>
    <message>
        <location filename="../src/VariableModel.cpp" line="37"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../src/VariableModel.cpp" line="39"/>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
</context>
</TS>